from fastapi import FastAPI, UploadFile, File
from google.cloud import vision
import uvicorn
import os

# ⭐ 키파일 경로 직접 지정 → 이러면 환경변수 안 써도 됨!!
os.environ["GOOGLE_APPLICATION_CREDENTIALS"] = r"C:\Users\tjckd\OneDrive\바탕 화면\scaneat_server\scaneat_server\scaneat-36276-d875f18f356c.json"

app = FastAPI()

# Google Vision API 클라이언트 생성
client = vision.ImageAnnotatorClient()

@app.get("/")
def home():
    return {"message": "ScanEat OCR Server Running!"}

@app.post("/ocr")
async def ocr_image(file: UploadFile = File(...)):
    image_content = await file.read()

    image = vision.Image(content=image_content)
    response = client.text_detection(image=image)

    if response.error.message:
        raise Exception(response.error.message)

    texts = response.text_annotations
    if not texts:
        return {"text": ""}

    extracted_text = texts[0].description
    return {"text": extracted_text}

if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
